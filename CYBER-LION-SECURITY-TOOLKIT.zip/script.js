function checkURL() {
  const value = document.getElementById("url").value.trim();
  const output = document.getElementById("urlResult");

  try {
    const u = new URL(value);

    if (!["http:", "https:"].includes(u.protocol)) {
      throw new Error("Unsupported protocol");
    }

    const warnings = [];

    if (u.protocol !== "https:") warnings.push("Not HTTPS");
    if (u.username || u.password) warnings.push("Contains embedded credentials");
    if (u.hostname.startsWith("xn--") || u.hostname.includes(".xn--")) {
      warnings.push("Internationalized domain — verify carefully");
    }

    output.textContent = warnings.length
      ? "Caution: " + warnings.join(", ") + "."
      : "No obvious URL pattern detected. This is NOT proof the site is safe.";
  } catch {
    output.textContent = "Invalid URL. Enter a complete URL.";
  }
}

async function hashFile() {
  const file = document.getElementById("file").files[0];
  const output = document.getElementById("hashResult");

  if (!file) {
    output.textContent = "Select a file first.";
    return;
  }

  output.textContent = "Generating SHA-256...";

  try {
    const data = await file.arrayBuffer();
    const hash = await crypto.subtle.digest("SHA-256", data);
    const hex = [...new Uint8Array(hash)]
      .map(b => b.toString(16).padStart(2, "0")).join("");

    output.textContent = "SHA-256: " + hex;
  } catch {
    output.textContent = "Use a secure browser context to calculate hash.";
  }
}

function checkPassword() {
  const p = document.getElementById("password").value;
  const output = document.getElementById("passResult");

  if (!p) {
    output.textContent = "Enter a test password.";
    return;
  }

  let score = 0;
  if (p.length >= 12) score++;
  if (/[A-Z]/.test(p)) score++;
  if (/[a-z]/.test(p)) score++;
  if (/[0-9]/.test(p)) score++;
  if (/[^A-Za-z0-9]/.test(p)) score++;

  const levels = ["Very weak", "Weak", "Fair", "Good", "Strong", "Strong"];
  output.textContent = "Estimated strength: " + levels[score] +
    ". This is a basic local estimate.";
}

function networkInfo() {
  const connection = navigator.connection;
  document.getElementById("networkResult").textContent =
    "Online: " + navigator.onLine +
    " | Connection: " + (connection?.effectiveType || "Not available");
}

function showChecklist() {
  document.getElementById("checkResult").textContent =
    "✓ Enable 2FA | ✓ Update software | ✓ Use unique passwords | ✓ Back up important files | ✓ Review account security.";
}

function report() {
  const content = [
    "CYBER LION SECURITY REPORT",
    "Generated: " + new Date().toLocaleString(),
    "Browser: " + navigator.userAgent,
    "Online: " + navigator.onLine,
    "Toolkit: V1.0"
  ].join("\n");

  const blob = new Blob([content], { type: "text/plain" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = "cyber-lion-report.txt";
  link.click();
  URL.revokeObjectURL(link.href);

  document.getElementById("reportResult").textContent =
    "Local report download requested.";
}